import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { pool } from '../config/db';

const router = Router();

// Listar usuários (sem expor senha_hash)
router.get('/', async (_req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT id_usuario, nome, email, perfil, identificacao, ativo, data_cadastro
       FROM usuarios`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao buscar usuários' });
  }
});

// Buscar por id
router.get('/:id', async (req, res) => {
  try {
    const [rows]: any = await pool.query(
      `SELECT id_usuario, nome, email, perfil, identificacao, ativo, data_cadastro
       FROM usuarios WHERE id_usuario = ?`,
      [req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ erro: 'Usuário não encontrado' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao buscar usuário' });
  }
});

// Criar usuário (senha é hasheada)
router.post('/', async (req, res) => {
  const { nome, email, senha, perfil, identificacao } = req.body;

  if (!nome || !email || !senha || !perfil) {
    return res.status(400).json({ erro: 'Campos obrigatórios: nome, email, senha, perfil' });
  }

  const perfisValidos = ['ADMIN', 'PROFESSOR', 'PARTICIPANTE'];
  if (!perfisValidos.includes(perfil)) {
    return res.status(400).json({ erro: 'Perfil inválido' });
  }

  try {
    const senha_hash = await bcrypt.hash(senha, 10);

    const [result]: any = await pool.query(
      `INSERT INTO usuarios (nome, email, senha_hash, perfil, identificacao)
       VALUES (?, ?, ?, ?, ?)`,
      [nome, email, senha_hash, perfil, identificacao ?? null]
    );

    res.status(201).json({
      id_usuario: result.insertId,
      nome,
      email,
      perfil,
      identificacao: identificacao ?? null,
    });
  } catch (err: any) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ erro: 'E-mail já cadastrado' });
    }
    console.error(err);
    res.status(500).json({ erro: 'Erro ao criar usuário' });
  }
});

export default router;