import { Router } from 'express';
import { pool } from '../config/db';

const router = Router();

// Listar eventos com JOIN
router.get('/', async (_req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        e.id_evento, e.titulo, e.data_evento, e.horario, e.local,
        e.descricao, e.tipo_evento, e.limite_inscricoes, e.status,
        u.nome  AS criador,
        c.nome  AS categoria
      FROM eventos e
      JOIN usuarios   u ON u.id_usuario   = e.id_criador
      LEFT JOIN categorias c ON c.id_categoria = e.id_categoria
      ORDER BY e.data_evento, e.horario
    `);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao buscar eventos' });
  }
});

// Buscar por id
router.get('/:id', async (req, res) => {
  try {
    const [rows]: any = await pool.query(
      `SELECT e.*, u.nome AS criador, c.nome AS categoria
       FROM eventos e
       JOIN usuarios u ON u.id_usuario = e.id_criador
       LEFT JOIN categorias c ON c.id_categoria = e.id_categoria
       WHERE e.id_evento = ?`,
      [req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ erro: 'Evento não encontrado' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao buscar evento' });
  }
});

// Criar evento
router.post('/', async (req, res) => {
  const {
    titulo, data_evento, horario, local, descricao,
    tipo_evento, limite_inscricoes, status, id_criador, id_categoria,
  } = req.body;

  if (!titulo || !data_evento || !horario || !local || !tipo_evento || !limite_inscricoes || !id_criador) {
    return res.status(400).json({
      erro: 'Campos obrigatórios: titulo, data_evento, horario, local, tipo_evento, limite_inscricoes, id_criador',
    });
  }

  try {
    const [result]: any = await pool.query(
      `INSERT INTO eventos
        (titulo, data_evento, horario, local, descricao,
         tipo_evento, limite_inscricoes, status, id_criador, id_categoria)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        titulo,
        data_evento,
        horario,
        local,
        descricao ?? null,
        tipo_evento,
        limite_inscricoes,
        status ?? 'ATIVO',
        id_criador,
        id_categoria ?? null,
      ]
    );

    res.status(201).json({ id_evento: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao criar evento' });
  }
});

export default router;