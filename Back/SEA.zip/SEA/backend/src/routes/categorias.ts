import { Router } from 'express';
import { pool } from '../config/db';

const router = Router();

// Listar
router.get('/', async (_req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM categorias');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao buscar categorias' });
  }
});

// Criar
router.post('/', async (req, res) => {
  const { nome, descricao } = req.body;
  if (!nome) return res.status(400).json({ erro: 'Campo "nome" é obrigatório' });

  try {
    const [result]: any = await pool.query(
      'INSERT INTO categorias (nome, descricao) VALUES (?, ?)',
      [nome, descricao ?? null]
    );
    res.status(201).json({ id_categoria: result.insertId, nome, descricao: descricao ?? null });
  } catch (err: any) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ erro: 'Categoria já existe' });
    }
    console.error(err);
    res.status(500).json({ erro: 'Erro ao criar categoria' });
  }
});

export default router;