import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import usuariosRoutes from './routes/usuarios';
import categoriasRoutes from './routes/categorias';
import eventosRoutes from './routes/eventos';
import { testarConexao } from './config/db';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.use('/usuarios', usuariosRoutes);
app.use('/categorias', categoriasRoutes);
app.use('/eventos', eventosRoutes);

const PORT = process.env.PORT || 3000;

app.listen(PORT, async () => {
  console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
  await testarConexao();
});