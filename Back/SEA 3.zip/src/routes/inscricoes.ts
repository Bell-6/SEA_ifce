import { Router } from 'express';
import { pool } from '../config/db';
import { verificarToken, AuthRequest } from '../middlewares/authMiddleware';

const router = Router();


router.post('/eventos/:idEvento', verificarToken, async (req: AuthRequest, res) => {
  const id_usuario = req.usuario?.id;
  const { idEvento } = req.params;

  try {
   
    const [eventoRows]: any = await pool.query(
      'SELECT status, limite_inscricoes FROM eventos WHERE id_evento = ?',
      [idEvento]
    );

    if (eventoRows.length === 0) {
      return res.status(404).json({ erro: 'Evento não encontrado' });
    }

    const evento = eventoRows[0];

   
    if (evento.status !== 'ATIVO') {
      return res.status(400).json({ erro: 'Este evento não está aceitando inscrições no momento.' });
    }

    
    const [vagasRows]: any = await pool.query(
      "SELECT COUNT(*) AS total_confirmadas FROM inscricoes WHERE id_evento = ? AND status = 'CONFIRMADA'",
      [idEvento]
    );
    
    const totalConfirmadas = vagasRows[0].total_confirmadas;

    if (totalConfirmadas >= evento.limite_inscricoes) {
      return res.status(400).json({ erro: 'Desculpe, as vagas para este evento estão esgotadas.' });
    }

   
    const [inscricaoRows]: any = await pool.query(
      'SELECT id_inscricao, status FROM inscricoes WHERE id_usuario = ? AND id_evento = ?',
      [id_usuario, idEvento]
    );

    if (inscricaoRows.length > 0) {
      const inscricao = inscricaoRows[0];
      
      if (inscricao.status === 'CONFIRMADA') {
        return res.status(400).json({ erro: 'Você já está inscrito neste evento.' });
      } else {
    
        await pool.query(
          "UPDATE inscricoes SET status = 'CONFIRMADA', data_inscricao = CURRENT_TIMESTAMP WHERE id_inscricao = ?",
          [inscricao.id_inscricao]
        );
        return res.status(200).json({ mensagem: 'Inscrição reativada com sucesso!' });
      }
    }

    
    await pool.query(
      "INSERT INTO inscricoes (id_usuario, id_evento, status) VALUES (?, ?, 'CONFIRMADA')",
      [id_usuario, idEvento]
    );

    res.status(201).json({ 
      mensagem: 'Inscrição realizada com sucesso!',
      vaga_garantida: true 
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao processar inscrição' });
  }
});


router.delete('/eventos/:idEvento', verificarToken, async (req: AuthRequest, res) => {
  const id_usuario = req.usuario?.id;
  const { idEvento } = req.params;

  try {
  
    const [rows]: any = await pool.query(
      "SELECT id_inscricao FROM inscricoes WHERE id_usuario = ? AND id_evento = ? AND status = 'CONFIRMADA'",
      [id_usuario, idEvento]
    );

    if (rows.length === 0) {
      return res.status(404).json({ erro: 'Inscrição ativa não encontrada para este evento.' });
    }

    
    await pool.query(
      "UPDATE inscricoes SET status = 'CANCELADA' WHERE id_usuario = ? AND id_evento = ?",
      [id_usuario, idEvento]
    );

    res.json({ mensagem: 'Inscrição cancelada com sucesso. A vaga foi liberada.' });

  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao cancelar inscrição' });
  }
});


router.get('/minhas-inscricoes', verificarToken, async (req: AuthRequest, res) => {
  const id_usuario = req.usuario?.id;

  try {
    const [rows] = await pool.query(
      `SELECT i.id_inscricao, i.status AS status_inscricao, i.data_inscricao,
              e.id_evento, e.titulo, e.data_evento, e.horario, e.local
       FROM inscricoes i
       JOIN eventos e ON e.id_evento = i.id_evento
       WHERE i.id_usuario = ? AND i.status = 'CONFIRMADA'`,
      [id_usuario]
    );

    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao buscar suas inscrições' });
  }
});

export default router;