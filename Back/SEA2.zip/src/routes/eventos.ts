import { Router } from 'express';
import { pool } from '../config/db';
import { verificarToken, AuthRequest } from '../middlewares/authMiddleware';

const router = Router();


router.get('/', async (_req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        e.id_evento, e.titulo, e.data_evento, e.horario, e.local,
        e.descricao, e.tipo_evento, e.limite_inscricoes, e.status,
        u.nome AS criador,
        c.nome AS categoria
      FROM eventos e
      JOIN usuarios u ON u.id_usuario = e.id_criador
      LEFT JOIN categorias c ON c.id_categoria = e.id_categoria
      ORDER BY e.data_evento, e.horario
    `);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao buscar eventos' });
  }
});


router.get('/:id', async (req, res) => {
  try {
    const [rows]: any = await pool.query(
      `SELECT e.*, u.nome AS criador, c.nome AS categoria
       FROM eventos e
       JOIN usuarios u ON u.id_usuario = e.id_criador
       LEFT JOIN categorias c ON c.id_categoria = e.id_categoria
       WHERE e.id_evento = ?`,
      [req.params.id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ erro: 'Evento não encontrado' });
    }

    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao buscar evento' });
  }
});


router.post('/', verificarToken, async (req: AuthRequest, res) => {
  const {
    titulo, data_evento, horario, local, descricao,
    tipo_evento, limite_inscricoes, status, id_categoria,
  } = req.body;

  const id_criador = req.usuario?.id; 

  if (!titulo || !data_evento || !horario || !local || !tipo_evento || !limite_inscricoes) {
    return res.status(400).json({
      erro: 'Campos obrigatórios: titulo, data_evento, horario, local, tipo_evento, limite_inscricoes',
    });
  }

  try {
    const [result]: any = await pool.query(
      `INSERT INTO eventos
        (titulo, data_evento, horario, local, descricao,
         tipo_evento, limite_inscricoes, status, id_criador, id_categoria)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        titulo,
        data_evento,
        horario,
        local,
        descricao ?? null,
        tipo_evento,
        limite_inscricoes,
        status ?? 'ATIVO',
        id_criador,
        id_categoria ?? null,
      ]
    );

    res.status(201).json({
      mensagem: 'Evento criado com sucesso!',
      id_evento: result.insertId,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao criar evento' });
  }
});


router.put('/:id', verificarToken, async (req: AuthRequest, res) => {
  const { id } = req.params;
  const {
    titulo, data_evento, horario, local, descricao,
    tipo_evento, limite_inscricoes, status, id_categoria,
  } = req.body;

  try {
    const [existe]: any = await pool.query(
      'SELECT id_evento FROM eventos WHERE id_evento = ?',
      [id]
    );

    if (existe.length === 0) {
      return res.status(404).json({ erro: 'Evento não encontrado' });
    }

    await pool.query(
      `UPDATE eventos SET
         titulo = COALESCE(?, titulo),
         data_evento = COALESCE(?, data_evento),
         horario = COALESCE(?, horario),
         local = COALESCE(?, local),
         descricao = COALESCE(?, descricao),
         tipo_evento = COALESCE(?, tipo_evento),
         limite_inscricoes = COALESCE(?, limite_inscricoes),
         status = COALESCE(?, status),
         id_categoria = COALESCE(?, id_categoria)
       WHERE id_evento = ?`,
      [
        titulo ?? null,
        data_evento ?? null,
        horario ?? null,
        local ?? null,
        descricao ?? null,
        tipo_evento ?? null,
        limite_inscricoes ?? null,
        status ?? null,
        id_categoria ?? null,
        id,
      ]
    );

    res.json({ mensagem: 'Evento atualizado com sucesso!' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao atualizar evento' });
  }
});


router.delete('/:id', verificarToken, async (req: AuthRequest, res) => {
  const { id } = req.params;

  try {
    const [existe]: any = await pool.query(
      'SELECT id_evento FROM eventos WHERE id_evento = ?',
      [id]
    );

    if (existe.length === 0) {
      return res.status(404).json({ erro: 'Evento não encontrado' });
    }

    await pool.query('DELETE FROM eventos WHERE id_evento = ?', [id]);

    res.json({ mensagem: 'Evento excluído com sucesso!' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Erro ao excluir evento' });
  }
});

export default router;